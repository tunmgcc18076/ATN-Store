
const mongoose = require('mongoose');
const url = "mongodb+srv://nguyentu:112233aA@cluster0.3jldx.mongodb.net/myFirstDatabase?authSource=admin&replicaSet=atlas-46xw6p-shard-0&w=majority&readPreference=primary&appname=MongoDB%20Compass&retryWrites=true&ssl=true"
mongoose.connect(url,{useNewUrlParser:true},(err) => {
    if(!err){ console.log("MongoDB Connection Succeeded");}
    else{
        console.log("An Error Occured");
    } 
})

require('./product.model');